# The Landing Page Project

## Languages used:

- HTML5
- CSS3
- Javscript (Js)
## Project functionalities:
1. The dynamic active class.

2. The Scroll event.

3. The navigation.

4. The scroll to top.

## Instructions:
First, you open your web browser.
Second, you press 'cltr + O' key from your keyboard.
The user can scroll up and down using the vertical scroll bar.
The user can also jump directly to each by clicking on the navigation menu links at the top. 

## Resources:
* w3school.com
* mdn.com
* getBoundClientRect() by dcode
